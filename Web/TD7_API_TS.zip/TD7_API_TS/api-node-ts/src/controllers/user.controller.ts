import { Request, Response } from 'express';

// Déclare un tableau en mémoire pour stocker les utilisateurs
let users: { name: string, email: string }[] = []; // Il n'y a pas d'utilisateurs au départ

/**
 * Contrôleur pour la route GET /users
 * Renvoie la liste des utilisateurs
 * @param req - Objet représentant la requête HTTP
 * @param res - Objet permettant d'envoyer une réponse HTTP
 */
export const getUsers = (req: Request, res: Response) => {
  // Renvoie tous les utilisateurs dans la réponse
  res.json(users); 
};

/**
 * Contrôleur pour la route POST /users
 * Ajoute un nouvel utilisateur en récupérant les données du corps de la requête
 * @param req - Objet représentant la requête HTTP contenant les données utilisateur
 * @param res - Objet permettant d'envoyer une réponse HTTP
 */
export const addUser = (req: Request, res: Response) => {
  const { name, email } = req.body;

  // Validation basique : vérifie si le nom et l'email sont présents
  if (!name || !email) {
    return res.status(400).json({ message: 'Le nom et l\'email sont requis.' });
  }

  // Ajout de l'utilisateur dans le tableau en mémoire
  const newUser = { name, email };
  users.push(newUser); // L'utilisateur est ajouté ici

  // Réponse avec l'utilisateur ajouté
  res.status(201).json({ message: `Utilisateur ${name} ajouté avec succès !`});
};
